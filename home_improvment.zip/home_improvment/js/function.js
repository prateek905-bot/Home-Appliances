
$('.menu_icon_sec > a').on('click', function(){
    $('body').addClass('active_menu');
});
$('.cross_icon span').on('click', function(){
    $('body').removeClass('active_menu');
});

$(document).ready(function () {
    $('.nav li a + i').on("click", function (e) {
        e.preventDefault();
        $(this).parent().find('>ul').slideToggle(100);
    });
});

var swiper = new Swiper(".banner_slider", {
    slidesPerView: 1,
    spaceBetween: 0,
	speed: 500,
	loop: true,
	// autoplay: {
	// 	delay: 3000,
	// 	disableOnInteraction: false,
	// },
	navigation: {
        nextEl: ".slider_btn_next",
        prevEl: ".slider_btn_prev",
    }
});



$(window).scroll(function(){
	var sticky = $('header'),
	scroll = $(window).scrollTop();
	if (scroll >= 150){
		sticky.addClass('fixed_header');
		$('body').css("", header_height);
	}
	else {
		sticky.removeClass('fixed_header');
	  $('body').css("", "0");
	  }
  });

// Search open
const search = document.querySelector('.search');
const bar = document.querySelector('.search-bar');
const btn = document.querySelector('.search-btn');
function activate() {
  search.classList.toggle('active');
  bar.value = '';
  setTimeout(() => bar.focus(),750)
}
btn.addEventListener('click',activate,false);
// Search close

var loader = document.getElementById('page_loader');
window.addEventListener('load', function(){
	loader.style.display = 'none';
});

$(document).ready(function(){
	$('.h_height').matchHeight();
});